# Code of Conduct

Please read the [Go Community Code of Conduct](https://golang.org/conduct).
